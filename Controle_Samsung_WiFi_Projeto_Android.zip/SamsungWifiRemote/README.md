# Controle Samsung Wi-Fi — Android (Java)

Projeto-fonte Android nativo, sem bibliotecas de terceiros ou contas externas.

## Recursos
- Buscar TVs Samsung na rede local via SSDP (com verificação do endpoint HTTP da TV)
- Conectar manualmente pelo IPv4 da TV (endereços de LAN privados RFC 1918)
- Conectar usando WebSocket seguro (`wss://IP:8002`) com fallback para `ws://IP:8001`
- Solicitar autorização pelo diálogo exibido na TV, salvar token de pareamento por IP
- Volume, mudo, canais, teclas de navegação, home, menu, fonte, número e mídia
- Interface escura e responsiva, com acessibilidade básica do Android

## Compatibilidade
Destinado principalmente a Samsung Smart TVs com Tizen (a partir de ~2016).
Modelos mais antigos requerem protocolos diferentes. TV e Android devem estar na
mesma rede local. Nem todas as teclas estão disponíveis em todos os modelos.
O botão de energia pode desligar a TV, mas o acionamento a partir do estado
desligado geralmente exige Wake-on-LAN, que não faz parte desta versão.

## Como compilar o APK
1. Instale **Android Studio** e seus componentes **Android SDK Platform 35**.
2. Abra **a pasta `SamsungWifiRemote`** como um projeto Android/Gradle.
3. Deixe o Android Studio configurar/sincronizar o Gradle. Caso solicite um Gradle
   instalado, configure um Gradle 8.9 ou gere um wrapper usando `gradle wrapper --gradle-version 8.9`.
4. Clique em **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. O arquivo estará em `app/build/outputs/apk/debug/app-debug.apk`.

Alternativamente, num computador com SDK/Gradle configurados:

```bash
gradle :app:assembleDebug
```

## Como usar
1. Verifique se a TV está ligada e conectada à rede do celular.
2. Instale o APK. Abra o aplicativo e toque em **Buscar**, ou digite o IP.
3. Toque em **Conectar** e escolha **Permitir** na TV quando solicitado.
4. Use os botões; o endereço e o token são memorizados no dispositivo.

## Segurança e limitações
- A conexão via TLS utiliza certificado autoassinado da TV. Este aplicativo
  aceita o certificado somente no socket destinado ao IP escolhido, mas não
  verifica sua identidade. Use somente numa rede local confiável.
- A porta 8001 usa WebSocket sem criptografia em modelos que permitem isso.
- Tokens ficam armazenados em preferências locais privadas do app; backups Android
  são desativados. Nenhuma informação é enviada para servidores externos.
- Buscas SSDP podem falhar em roteadores que bloqueiam multicast. Digite o IP.
- Projeto sem testes em hardware Samsung real; variações por firmware são possíveis.
- O projeto é independente, não oficial, sem vínculo com Samsung Electronics.
