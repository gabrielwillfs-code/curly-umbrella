package com.local.samsungremote;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(13, 19, 30);
    private static final int PANEL = Color.rgb(24, 34, 50);
    private static final int BUTTON = Color.rgb(37, 51, 72);
    private static final int ACCENT = Color.rgb(95, 172, 243);
    private static final int TEXT = Color.rgb(237, 245, 255);
    private static final int MUTED = Color.rgb(158, 179, 207);
    private SharedPreferences prefs;
    private SamsungRemoteClient remote;
    private EditText ipField;
    private TextView status;
    private TextView subtitle;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        prefs = getSharedPreferences("samsung-remote", MODE_PRIVATE);
        remote = new SamsungRemoteClient(new SamsungRemoteClient.Listener() {
            @Override public void onStatus(String text) { showStatus(text, false); }
            @Override public void onConnected(String token) {
                if (isFinishing() || isDestroyed()) return;
                if (!token.isEmpty()) prefs.edit().putString("token_" + remote.getCurrentIp(), token).apply();
                prefs.edit().putString("last_ip", remote.getCurrentIp()).apply();
                showStatus("●  Conectado à TV", true);
                subtitle.setText("Pronto para controlar a televisão");
            }
            @Override public void onDisconnected(String reason) {
                showStatus("Desconectado: " + reason, false);
            }
        });
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setPadding(dp(18), dp(22), dp(18), dp(26));
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("CONTROLE SAMSUNG", 23, TEXT, true);
        root.addView(title);
        subtitle = text("Controle remoto local • Wi-Fi", 13, MUTED, false);
        marginTop(root, subtitle, 4);

        LinearLayout connection = panel();
        marginTop(root, connection, 18);
        TextView label = text("Conexão com a TV", 16, TEXT, true);
        connection.addView(label);
        TextView helper = text("Conecte o celular e a televisão à mesma rede.", 12, MUTED, false);
        marginTop(connection, helper, 4);
        ipField = new EditText(this);
        ipField.setSingleLine(true);
        ipField.setTextColor(TEXT);
        ipField.setHintTextColor(MUTED);
        ipField.setHint("IP da TV • ex.: 192.168.1.50");
        ipField.setText(prefs.getString("last_ip", ""));
        ipField.setInputType(InputType.TYPE_CLASS_PHONE);
        ipField.setTextSize(16);
        ipField.setSelectAllOnFocus(true);
        ipField.setBackground(background(BG, 13));
        ipField.setPadding(dp(14), dp(9), dp(14), dp(9));
        marginTop(connection, ipField, 12);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        marginTop(connection, actions, 11);
        addButton(actions, "BUSCAR", () -> searchTv(), 1, false, ACCENT);
        addButton(actions, "CONECTAR", this::connectTv, 1, true, ACCENT);
        addButton(actions, "SAIR", () -> { remote.disconnect(); showStatus("Desconectado", false); }, 0.75f, false, MUTED);
        status = text("Informe o IP ou procure a TV na rede.", 13, MUTED, false);
        marginTop(connection, status, 12);

        LinearLayout pad = panel();
        marginTop(root, pad, 18);
        pad.addView(text("NAVEGAÇÃO", 12, MUTED, true));
        buttonRow(pad, new String[][] { {"⏻", "KEY_POWER"}, {"INÍCIO", "KEY_HOME"}, {"FONTE", "KEY_SOURCE"} }, 10);
        buttonRow(pad, new String[][] { {"", ""}, {"▲", "KEY_UP"}, {"", ""} }, 9);
        buttonRow(pad, new String[][] { {"◀", "KEY_LEFT"}, {"OK", "KEY_ENTER"}, {"▶", "KEY_RIGHT"} }, 2);
        buttonRow(pad, new String[][] { {"", ""}, {"▼", "KEY_DOWN"}, {"", ""} }, 2);
        buttonRow(pad, new String[][] { {"VOLTAR", "KEY_RETURN"}, {"MENU", "KEY_MENU"}, {"SAIR", "KEY_EXIT"} }, 8);

        LinearLayout controls = panel();
        marginTop(root, controls, 14);
        controls.addView(text("SOM E CANAIS", 12, MUTED, true));
        buttonRow(controls, new String[][] { {"VOL −", "KEY_VOLDOWN"}, {"SILÊNCIO", "KEY_MUTE"}, {"VOL +", "KEY_VOLUP"} }, 9);
        buttonRow(controls, new String[][] { {"CANAL −", "KEY_CHDOWN"}, {"GUIA", "KEY_GUIDE"}, {"CANAL +", "KEY_CHUP"} }, 3);

        LinearLayout media = panel();
        marginTop(root, media, 14);
        media.addView(text("MÍDIA E INFORMAÇÕES", 12, MUTED, true));
        buttonRow(media, new String[][] { {"◀◀", "KEY_REWIND"}, {"▶ / ❚❚", "KEY_PLAY"}, {"▶▶", "KEY_FF"} }, 9);
        buttonRow(media, new String[][] { {"PAUSAR", "KEY_PAUSE"}, {"PARAR", "KEY_STOP"}, {"INFO", "KEY_INFO"} }, 3);

        LinearLayout digits = panel();
        marginTop(root, digits, 14);
        digits.addView(text("TECLADO NUMÉRICO", 12, MUTED, true));
        for (int i = 1; i <= 7; i += 3) {
            buttonRow(digits, new String[][] { {""+i,"KEY_"+i}, {""+(i+1),"KEY_"+(i+1)}, {""+(i+2),"KEY_"+(i+2)} }, i == 1 ? 9 : 3);
        }
        buttonRow(digits, new String[][] { {"PRE-CH", "KEY_PRECH"}, {"0", "KEY_0"}, {"TOOLS", "KEY_TOOLS"} }, 3);

        TextView info = text("A primeira conexão exige autorização na TV. A tecla de energia normalmente desliga, mas pode não ligar novamente pela rede. Nem todos os botões são aceitos em todos os modelos.", 12, MUTED, false);
        info.setLineSpacing(dp(2), 1.0f);
        marginTop(root, info, 16);
    }

    private void buttonRow(LinearLayout parent, String[][] keys, int topMargin) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        marginTop(parent, row, topMargin);
        for (String[] key : keys) {
            if (key[1].isEmpty()) {
                View filler = new View(this);
                row.addView(filler, new LinearLayout.LayoutParams(0, dp(57), 1));
            } else {
                String name = key[0];
                addButton(row, name, () -> {
                    if (!remote.isConnected()) {
                        Toast.makeText(this, "Conecte à TV primeiro", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    vibrate();
                    remote.sendKey(key[1]);
                }, 1, name.equals("OK"), name.equals("⏻") ? Color.rgb(255, 137, 137) : ACCENT);
            }
        }
    }

    private void connectTv() {
        String ip = ipField.getText().toString().trim();
        if (!isValidIp(ip)) {
            ipField.setError("Digite um IP IPv4 válido da rede local");
            return;
        }
        prefs.edit().putString("last_ip", ip).apply();
        showStatus("Conectando…", false);
        remote.connect(ip, prefs.getString("token_" + ip, ""));
    }

    private void searchTv() {
        showStatus("Procurando TVs Samsung na rede…", false);
        new Thread(() -> {
            List<TvDiscovery.Tv> result = TvDiscovery.scan(this);
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                if (result.isEmpty()) {
                    showStatus("Nenhuma TV encontrada. Informe o IP manualmente.", false);
                    new AlertDialog.Builder(this)
                        .setTitle("Nenhuma TV encontrada")
                        .setMessage("Confira se a TV está ligada e na mesma rede Wi-Fi. É possível digitar o IP manualmente.")
                        .setPositiveButton("OK", null).show();
                    return;
                }
                String[] options = new String[result.size()];
                for (int i = 0; i < result.size(); i++) options[i] = result.get(i).toString();
                showStatus(result.size() + " TV(s) encontrada(s)", false);
                new AlertDialog.Builder(this).setTitle("Escolha sua TV")
                    .setItems(options, (d, index) -> {
                        ipField.setText(result.get(index).ip);
                        connectTv();
                    }).setNegativeButton("Cancelar", null).show();
            });
        }, "tv-discovery").start();
    }

    private static boolean isValidIp(String ip) {
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) return false;
        try {
            for (String part : parts) {
                if (part.isEmpty() || part.length() > 3 || !part.matches("[0-9]+")) return false;
                int n = Integer.parseInt(part);
                if (n < 0 || n > 255) return false;
            }
            int a = Integer.parseInt(parts[0]);
            int b = Integer.parseInt(parts[1]);
            return a == 10 || (a == 172 && b >= 16 && b <= 31) || (a == 192 && b == 168);
        } catch (NumberFormatException ex) { return false; }
    }

    private void showStatus(String message, boolean success) {
        if (status == null || isFinishing() || isDestroyed()) return;
        status.setText(message);
        status.setTextColor(success ? Color.rgb(139, 231, 170) : MUTED);
    }

    private void addButton(LinearLayout parent, String label, Runnable press, float weight, boolean primary, int color) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(primary ? BG : (label.equals("⏻") ? color : TEXT));
        button.setAllCaps(false);
        button.setTextSize(label.length() > 6 ? 11 : 17);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(57));
        button.setMinimumHeight(dp(57));
        button.setPadding(dp(3), 0, dp(3), 0);
        button.setBackground(background(primary ? color : BUTTON, 13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(57), weight);
        lp.setMargins(dp(3), 0, dp(3), 0);
        parent.addView(button, lp);
        button.setOnClickListener(v -> press.run());
    }
    private void vibrate() {
        try {
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator != null && vibrator.hasVibrator()) {
                // Vibrar é opcional; depende de VIBRATE no manifesto.
                vibrator.vibrate(12);
            }
        } catch (Exception ignored) { }
    }
    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(12), dp(14), dp(12), dp(14));
        p.setBackground(background(PANEL, 18));
        return p;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private GradientDrawable background(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }
    private void marginTop(LinearLayout parent, View view, int top) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(top);
        parent.addView(view, params);
    }
    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    @Override protected void onDestroy() {
        remote.disconnect();
        super.onDestroy();
    }
}
