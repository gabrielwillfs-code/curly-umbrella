package com.local.samsungremote;

import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLEncoder;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

/**
 * Cliente WebSocket RFC 6455 básico, sem bibliotecas externas.
 * O TLS autocertificado é aceito SOMENTE no socket que aponta ao IP escolhido.
 * Use exclusivamente em uma rede local confiável.
 */
public final class SamsungRemoteClient {
    public interface Listener {
        void onStatus(String status);
        void onConnected(String token);
        void onDisconnected(String reason);
    }

    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService writer = Executors.newSingleThreadExecutor();
    private final Object writeLock = new Object();
    private final AtomicInteger generation = new AtomicInteger();
    private final SecureRandom random = new SecureRandom();
    private volatile Socket socket;
    private volatile OutputStream output;
    private volatile boolean connected;
    private volatile String currentIp;

    public SamsungRemoteClient(Listener listener) { this.listener = listener; }

    private void status(String message) { ui.post(() -> listener.onStatus(message)); }
    private void disconnected(String reason) { ui.post(() -> listener.onDisconnected(reason)); }
    private void connected(String token) { ui.post(() -> listener.onConnected(token)); }

    public boolean isConnected() { return connected; }
    public String getCurrentIp() { return currentIp; }

    public void connect(String ip, String savedToken) {
        disconnectSilently();
        final int ticket = generation.incrementAndGet();
        currentIp = ip;
        new Thread(() -> {
            status("Conectando com " + ip + "…");
            try {
                try {
                    doConnect(ip, savedToken, true, ticket);
                } catch (HandshakeException error) {
                    if (ticket != generation.get()) return;
                    status("Tentando conexão alternativa (porta 8001)…");
                    doConnect(ip, savedToken, false, ticket);
                }
            } catch (Exception error) {
                if (ticket == generation.get()) {
                    connected = false;
                    closeSocket();
                    disconnected(humanError(error));
                }
            }
        }, "samsung-remote-reader").start();
    }

    private void doConnect(String ip, String savedToken, boolean secure, int ticket) throws Exception {
        Socket raw = new Socket();
        Socket active = raw;
        boolean handshakeComplete = false;
        try {
            raw.connect(new InetSocketAddress(ip, secure ? 8002 : 8001), 3500);
            raw.setSoTimeout(6000);
            if (secure) {
                // TVs Samsung geralmente apresentam certificados TLS autoassinados.
                TrustManager[] trust = new TrustManager[] { new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                    public void checkClientTrusted(X509Certificate[] chain, String authType) { }
                    public void checkServerTrusted(X509Certificate[] chain, String authType) { }
                }};
                SSLContext context = SSLContext.getInstance("TLS");
                context.init(null, trust, random);
                SSLSocket tls = (SSLSocket) context.getSocketFactory().createSocket(raw, ip, 8002, true);
                tls.startHandshake();
                active = tls;
            }
            if (ticket != generation.get()) { active.close(); return; }
            socket = active;
            InputStream in = active.getInputStream();
            OutputStream out = active.getOutputStream();
            String appName = Base64.encodeToString("Controle Samsung Wi-Fi".getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            String query = "/api/v2/channels/samsung.remote.control?name=" + URLEncoder.encode(appName, "UTF-8");
            if (savedToken != null && !savedToken.isEmpty()) {
                query += "&token=" + savedToken.replaceAll("[^A-Za-z0-9_-]", "");
            }
            byte[] nonce = new byte[16];
            random.nextBytes(nonce);
            String key = Base64.encodeToString(nonce, Base64.NO_WRAP);
            String request = "GET " + query + " HTTP/1.1\r\n" +
                    "Host: " + ip + ":" + (secure ? 8002 : 8001) + "\r\n" +
                    "Upgrade: websocket\r\nConnection: Upgrade\r\n" +
                    "Sec-WebSocket-Key: " + key + "\r\n" +
                    "Sec-WebSocket-Version: 13\r\n\r\n";
            out.write(request.getBytes(StandardCharsets.US_ASCII));
            out.flush();
            String headers = readHttpHeaders(in);
            String first = headers.substring(0, headers.indexOf("\r\n"));
            if (!first.contains(" 101 ")) throw new HandshakeException("TV não aceitou WebSocket: " + first);
            String expected = Base64.encodeToString(
                    MessageDigest.getInstance("SHA-1").digest((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").getBytes(StandardCharsets.US_ASCII)),
                    Base64.NO_WRAP);
            if (!headers.toLowerCase(Locale.ROOT).contains("sec-websocket-accept: " + expected.toLowerCase(Locale.ROOT))) {
                throw new HandshakeException("Resposta WebSocket inválida");
            }
            handshakeComplete = true;
            output = out;
            status("Aguarde e aceite a autorização na TV, se aparecer…");
            active.setSoTimeout(30000);
            boolean accepted = false;
            while (ticket == generation.get()) {
                Frame frame = readFrame(in);
                if (frame.opcode == 8) throw new IOException("A TV encerrou a conexão");
                if (frame.opcode == 9) { sendFrame((byte) 10, frame.data, out); continue; }
                if (frame.opcode != 1) continue;
                String message = new String(frame.data, StandardCharsets.UTF_8);
                JSONObject obj = new JSONObject(message);
                String event = obj.optString("event", "");
                if (event.equals("ms.channel.connect")) {
                    JSONObject data = obj.optJSONObject("data");
                    String token = data == null ? "" : data.optString("token", "");
                    accepted = true;
                    if (ticket != generation.get()) return;
                    connected = true;
                    active.setSoTimeout(0);
                    connected(token);
                    break;
                }
                if (event.contains("unauthorized") || event.contains("error")) {
                    throw new IOException("A TV recusou a autorização: " + event);
                }
            }
            if (!accepted) return;
            while (ticket == generation.get()) {
                Frame frame = readFrame(in);
                if (frame.opcode == 8) throw new IOException("TV desconectada");
                if (frame.opcode == 9) sendFrame((byte) 10, frame.data, out);
            }
        } catch (Exception error) {
            if (ticket == generation.get()) closeSocket();
            else try { active.close(); } catch (IOException ignored) { }
            // Fallback só quando o canal 8002 não abriu. Se o handshake WebSocket
            // passou, a autorização ou a sessão não devem ser repetidas na 8001.
            if (secure && !handshakeComplete) throw new HandshakeException(error.getMessage(), error);
            throw error;
        } finally {
            if (ticket != generation.get() || !connected) {
                try { raw.close(); } catch (IOException ignored) { }
            }
        }
    }

    public void sendKey(String key) {
        if (!key.matches("KEY_[A-Z0-9_]+")) return;
        if (!connected || output == null) { status("Conecte à TV antes de enviar comandos"); return; }
        writer.execute(() -> {
            if (!connected || output == null) return;
            try {
                JSONObject params = new JSONObject();
                params.put("Cmd", "Click");
                params.put("DataOfCmd", key);
                params.put("Option", "false");
                params.put("TypeOfRemote", "SendRemoteKey");
                JSONObject command = new JSONObject();
                command.put("method", "ms.remote.control");
                command.put("params", params);
                sendFrame((byte) 1, command.toString().getBytes(StandardCharsets.UTF_8), output);
            } catch (Exception e) {
                connected = false;
                closeSocket();
                disconnected("Falha ao enviar comando: " + humanError(e));
            }
        });
    }

    public void disconnect() {
        disconnectSilently();
        status("Desconectado");
    }
    private void disconnectSilently() {
        generation.incrementAndGet();
        connected = false;
        closeSocket();
    }
    private void closeSocket() {
        Socket old = socket;
        socket = null;
        output = null;
        if (old != null) try { old.close(); } catch (IOException ignored) { }
    }

    private void sendFrame(byte opcode, byte[] data, OutputStream out) throws IOException {
        synchronized (writeLock) {
            if (out == null) throw new IOException("Conexão indisponível");
            out.write(0x80 | opcode);
            int n = data.length;
            if (n < 126) out.write(0x80 | n);
            else if (n <= 65535) { out.write(0x80 | 126); out.write((n >> 8) & 255); out.write(n & 255); }
            else throw new IOException("Mensagem muito grande");
            byte[] mask = new byte[4];
            random.nextBytes(mask);
            out.write(mask);
            byte[] payload = new byte[n];
            for (int i = 0; i < n; i++) payload[i] = (byte) (data[i] ^ mask[i % 4]);
            out.write(payload);
            out.flush();
        }
    }

    private static Frame readFrame(InputStream in) throws IOException {
        int a = in.read();
        int b = in.read();
        if (a < 0 || b < 0) throw new EOFException("TV encerrou a conexão");
        int opcode = a & 15;
        int length = b & 127;
        if (length == 126) length = (readRequired(in) << 8) | readRequired(in);
        else if (length == 127) {
            long size = 0;
            for (int i = 0; i < 8; i++) size = (size << 8) | readRequired(in);
            if (size > 1024 * 1024) throw new IOException("Mensagem grande demais");
            length = (int) size;
        }
        if (length > 1024 * 1024) throw new IOException("Mensagem grande demais");
        byte[] mask = null;
        if ((b & 0x80) != 0) {
            mask = new byte[4];
            readFully(in, mask);
        }
        byte[] data = new byte[length];
        readFully(in, data);
        if (mask != null) for (int i = 0; i < length; i++) data[i] ^= mask[i % 4];
        return new Frame(opcode, data);
    }

    private static String readHttpHeaders(InputStream in) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        int previous3 = -1, previous2 = -1, previous1 = -1;
        while (bytes.size() < 16384) {
            int current = readRequired(in);
            bytes.write(current);
            if (previous3 == '\r' && previous2 == '\n' && previous1 == '\r' && current == '\n')
                return bytes.toString("US-ASCII");
            previous3 = previous2; previous2 = previous1; previous1 = current;
        }
        throw new IOException("Cabeçalho WebSocket grande demais");
    }
    private static int readRequired(InputStream in) throws IOException {
        int n = in.read();
        if (n < 0) throw new EOFException("Conexão encerrada");
        return n;
    }
    private static void readFully(InputStream in, byte[] target) throws IOException {
        int offset = 0;
        while (offset < target.length) {
            int n = in.read(target, offset, target.length - offset);
            if (n < 0) throw new EOFException("Conexão encerrada");
            offset += n;
        }
    }
    private static String humanError(Exception e) {
        String message = e.getMessage();
        if (e instanceof java.net.SocketTimeoutException) return "Tempo esgotado. Confira a autorização na TV e o IP.";
        if (e instanceof java.net.ConnectException) return "TV inacessível. Confira se está ligada e na mesma rede.";
        return message == null ? e.getClass().getSimpleName() : message;
    }
    private static class Frame {
        final int opcode; final byte[] data;
        Frame(int code, byte[] bytes) { opcode = code; data = bytes; }
    }
    private static class HandshakeException extends IOException {
        HandshakeException(String message) { super(message); }
        HandshakeException(String message, Throwable cause) { super(message, cause); }
    }
}
