package com.local.samsungremote;

import android.content.Context;
import android.net.wifi.WifiManager;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class TvDiscovery {
    public static final class Tv {
        public final String ip;
        public final String name;
        public Tv(String ip, String name) { this.ip = ip; this.name = name; }
        @Override public String toString() { return name + "  (" + ip + ")"; }
    }

    public static List<Tv> scan(Context context) {
        Map<String, Tv> found = new LinkedHashMap<>();
        WifiManager wifi = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        WifiManager.MulticastLock lock = null;
        try {
            if (wifi != null) {
                lock = wifi.createMulticastLock("samsungremote-discovery");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
            try (DatagramSocket socket = new DatagramSocket()) {
                socket.setSoTimeout(650);
                String request = "M-SEARCH * HTTP/1.1\r\n" +
                        "HOST: 239.255.255.250:1900\r\n" +
                        "MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n";
                byte[] body = request.getBytes(StandardCharsets.UTF_8);
                DatagramPacket query = new DatagramPacket(body, body.length,
                        InetAddress.getByName("239.255.255.250"), 1900);
                socket.send(query);
                socket.send(query);
                long until = System.currentTimeMillis() + 4500;
                while (System.currentTimeMillis() < until) {
                    byte[] response = new byte[4096];
                    DatagramPacket packet = new DatagramPacket(response, response.length);
                    try { socket.receive(packet); }
                    catch (java.net.SocketTimeoutException ignored) { continue; }
                    String ip = packet.getAddress().getHostAddress();
                    if (found.containsKey(ip)) continue;
                    String name = identifySamsung(ip);
                    if (name != null) found.put(ip, new Tv(ip, name));
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (lock != null && lock.isHeld()) lock.release();
        }
        return new ArrayList<>(found.values());
    }

    private static String identifySamsung(String ip) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL("http://" + ip + ":8001/api/v2/").openConnection();
            connection.setConnectTimeout(1300);
            connection.setReadTimeout(1300);
            if (connection.getResponseCode() != 200) return null;
            try (InputStream in = connection.getInputStream()) {
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buf = new byte[2048];
                int count;
                while ((count = in.read(buf)) != -1 && output.size() < 32768) output.write(buf, 0, count);
                String json = output.toString("UTF-8");
                JSONObject root = new JSONObject(json);
                JSONObject device = root.optJSONObject("device");
                if (device == null) return null;
                String model = device.optString("modelName", "");
                String type = device.optString("type", "");
                String name = device.optString("name", "");
                if (!json.toLowerCase().contains("samsung") && model.isEmpty() && !type.toLowerCase().contains("samsung")) return null;
                return name.isEmpty() ? (model.isEmpty() ? "Samsung TV" : "Samsung " + model) : name;
            }
        } catch (Exception ignored) { return null; }
        finally { if (connection != null) connection.disconnect(); }
    }
}
